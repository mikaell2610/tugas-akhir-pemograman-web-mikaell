<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <div class="alert alert-warning mt-4" role="alert">
                <strong>You're not an admin, are you?</strong>
            </div>
        </div>
    </body>
</html>
